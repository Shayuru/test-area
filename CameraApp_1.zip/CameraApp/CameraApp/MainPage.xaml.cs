﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Media.Capture;
using Windows.Storage;
using Windows.UI.Xaml.Media.Imaging;
using System.Threading.Tasks;
using Windows.Storage.Streams;
using System.Diagnostics;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace CameraApp
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        public MainPage()
        {
            this.InitializeComponent();
        }

        private async void button_Click(object sender, RoutedEventArgs e)
        {
            await ProcessPhotoRequest();
        }

        private async Task<string> ProcessPhotoRequest()
        {
            CameraCaptureUI captureUI = new CameraCaptureUI();
            captureUI.PhotoSettings.Format = CameraCaptureUIPhotoFormat.Jpeg;
            StorageFile photo = await captureUI.CaptureFileAsync(CameraCaptureUIMode.Photo);
            if (photo == null)
            {
                // User cancelled photo capture
                return "Cancel";
            }
            else
            {
                BitmapImage img = new BitmapImage();
                img = await LoadImage(photo);
                Debug.WriteLine(photo.Path);
                StorageFolder picsFolder = Windows.Storage.KnownFolders.SavedPictures;
                String photoName = "photo.jpg";
                var isExist = await picsFolder.TryGetItemAsync(photoName);
                if (isExist!=null)
                {
                    await isExist.DeleteAsync();
                }
                await photo.CopyAsync(picsFolder, photoName);
                txtPhoto.Text = picsFolder.Path + @"\" + photoName;
                imagePhoto.Source = img;
            }
            return "Finished";
        }
        private async Task<BitmapImage> LoadImage(StorageFile file)
        {
            BitmapImage bitmapImage = new BitmapImage();
            FileRandomAccessStream stream = (FileRandomAccessStream)await file.OpenAsync(FileAccessMode.Read);

            bitmapImage.SetSource(stream);

            return bitmapImage;

        }

        private void button1_Click(object sender, RoutedEventArgs e)
        {
            Uri uri = new Uri(txtURI.Text);
            LoadPage(uri);
        }
        private void LoadPage(Uri uri)
        {
            webViewBrowser.Navigate(uri);
        }

        private async void NavigationStarting(WebView sender, WebViewNavigationStartingEventArgs args)
        {
            if (!String.IsNullOrWhiteSpace(txtNavigationString.Text))
            {
                if (args.Uri.ToString().Contains(txtNavigationString.Text.Trim()))
                {
                    await ProcessPhotoRequest();
                }
            }
        }
    }
}
